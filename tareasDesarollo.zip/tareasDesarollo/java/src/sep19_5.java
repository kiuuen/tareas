// 5. Escribir un programa que visualice un triangulo isosceles
public class sep19_5 {
    public static void main(String[] args) {
        System.out.println("        *");
        System.out.println("      * * *");
        System.out.println("    * * * * *");
        System.out.println("  * * * * * * *");
        System.out.println("* * * * * * * * *");
    }
}
// era asi??